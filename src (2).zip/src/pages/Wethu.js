import { IonContent, IonPage, IonImg, IonButton
} from '@ionic/react';
import './Login.css';
import WhiteWethu from './WhiteWethu.jpg'

var myVar;

function myFunction() {
  myVar = setTimeout(showPage, 3000);
}

function showPage() {
  document.getElementById("load").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
const Wethu = () => {
    return (
        <IonPage onload={myFunction()}>
        <IonContent   className='ContentBlock'>

        <div id="loader">
        <IonImg id='load' src={WhiteWethu} className="WethuAnimation">

        </IonImg>
        </div>
        <IonButton style={{display:'none'}} id="myDiv" color="blue" className="LBtn">
          <div className="link1"><a href="./slider"> Continue</a></div>
        </IonButton>
        <div  id="myDiv" class="animate-bottom">
          <h2>Tada!</h2>
          <p>Some text in my newly loaded page..</p>
        </div>

        </IonContent>
  
      </IonPage>
    );
  };
  
  export default Wethu;
  